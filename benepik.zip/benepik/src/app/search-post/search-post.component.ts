import { Component, OnInit } from '@angular/core';
import { NewsService } from '../news.service';

@Component({
  selector: 'app-search-post',
  templateUrl: './search-post.component.html',
  styleUrls: ['./search-post.component.scss']
})
export class SearchPostComponent implements OnInit {

  title = 'benepik';
  news = []
  constructor(private newsService: NewsService) {}

  ngOnInit() {
    this.newsService.getPost().subscribe((res: any) => {
      console.log(res.data)
      this.news = res.data;
    }, err => {
      console.log(err)
    })
  }

}
