import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { RouterModule, Routes } from '@angular/router';
import { SearchPostComponent } from './search-post/search-post.component';

const route: Routes = [
  {path: "", component: SearchPostComponent},
  {path: "details/:id", component: PostDetailsComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    PostDetailsComponent,
    SearchPostComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(route)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
