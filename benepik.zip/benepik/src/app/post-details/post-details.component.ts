import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NewsService } from '../news.service';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.scss']
})
export class PostDetailsComponent implements OnInit {
  Id: any
  details: any
  constructor(private newsService: NewsService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe((res) => {
      console.log(res.id)
      // this.Id = id
      this.newsService.getPostDetails(res.id).subscribe((res: any) => {
        console.log(res.data)
        this.details = res.data
      }, err => {
        console.log(err)
      })
    })
   
  }

  onBack() {
    this.router.navigate([""])
  }

}
