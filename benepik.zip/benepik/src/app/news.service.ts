import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class NewsService {
  constructor(private http: HttpClient) {}
  
  getPost() {

    const data = {
      client_id: 'CO-33',
      empcode: '2',
      device: '2',
      deviceId: 'browser',
      app_version: '28',
      value: 0,
    };
    return this.http.post(
      'https://benepik.org/kpmg/APIs/News/Get_post',
      data,
      {
        headers: new HttpHeaders({
          authorization:
            'OUlBV0Z5Y1R2TDNnRjRTVmdMMStTQT09OjqZq1UZPSgSoDXMefyz5L/3',
        }),
      }
    );
  }

  getPostDetails(id) {
    const data = {
      client_id: 'CO-33',
      employee_id: '2',
      device: '2',
      device_id: 'browser',
      app_version: '28',
      post_id: id,
      newsType: '1',
    };

    return this.http.post('https://benepik.org/kpmg/APIs/News/Post_detail', data, 
    {
      headers: new HttpHeaders({
        authorization:
          'OUlBV0Z5Y1R2TDNnRjRTVmdMMStTQT09OjqZq1UZPSgSoDXMefyz5L/3',
      }),
    }
    );
  }
}
